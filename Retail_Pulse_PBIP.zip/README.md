# Retail Pulse

Interactive Power BI analysis of U.S. monthly retail and food-services sales by business category, using official U.S. Census Bureau Monthly Retail Trade Survey estimates.

## Coverage

- Monthly, seasonally adjusted sales estimates from January 2020 through May 2026
- 11 decision-relevant market categories
- Values are millions of current U.S. dollars and are not adjusted for inflation

## Dashboard pages

- **Executive Overview** — KPI strip, filled momentum area, and donut market-share composition
- **Market Momentum** — animated bubble quadrant plus treemap category composition
- **Category Explorer** — focused line trajectory and benchmark table
- **Methodology & Sources** — definitions, source coverage, limitations, and interpretation guardrails

## Portfolio design range

This report deliberately uses a different visual grammar from the earlier health and humanitarian dashboards. It combines area, donut, treemap, scatter, line, KPI, slicer, and benchmark-table views within a retail command-center layout.

## Data source

- U.S. Census Bureau Monthly Retail Trade Survey: https://www.census.gov/retail/sales.html
- Source workbook: https://www.census.gov/retail/mrts/www/mrtssales92-present.xlsx
- Retrieved: 11 August 2026

## Limitations

Recent estimates may be preliminary and revised. Values are seasonally adjusted for calendar effects but are not adjusted for price changes. The report presents descriptive patterns and does not infer causality.

## Review status

Local review build only. Not published to GitHub.
